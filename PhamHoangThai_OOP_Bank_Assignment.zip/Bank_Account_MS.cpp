#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <memory>
using namespace std;

class Account; // forward declaration

// ================= Transaction =================
class Transaction {
    double amount;
    string type;
    string date;

    string getCurrentDate() {
        time_t now = time(0);
        char buf[80];
        strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", localtime(&now));
        return string(buf);
    }

public:
    Transaction(double amt, string t) : amount(amt), type(t) {
        date = getCurrentDate();
    }

    void display() const {
        cout << "  [" << date << "] " << type << ": " << amount << endl;
    }

    // Operator overloading: apply transaction to an account
    friend Account& operator+=(Account& acc, const Transaction& t);

    // Compare transactions by amount + type
    bool operator==(const Transaction& other) const {
        return (amount == other.amount && type == other.type);
    }
};

// ================= Account (Base Class) =================
class Account {
protected:
    int accountnumber;
    double balance;
    string ownername;
    vector<Transaction> history;

public:
    Account(int accNo, string owner, double initialBalance = 0.0)
        : accountnumber(accNo), ownername(owner), balance(initialBalance) {}

    virtual ~Account() {}

    virtual void deposit(double amount) {
        balance += amount;
        *this += Transaction(amount, "Deposit");
    }

    virtual bool withdraw(double amount) {
        if (amount > balance) {
            cout << "Insufficient funds.\n";
            return false;
        }
        balance -= amount;
        *this += Transaction(amount, "Withdrawal");
        return true;
    }

    double getBalance() const { return balance; }

    string getOwner() const { return ownername; }

    int getAccountNumber() const { return accountnumber; }

    // Compare accounts by balance
    bool operator==(const Account& other) const {
        return this->balance == other.balance;
    }

    virtual void display() const {
        cout << "Account #" << accountnumber << " (" << ownername << ")"
             << " Balance: " << balance << endl;
        cout << "Transaction history:\n";
        for (const auto& t : history)
            t.display();
    }

    // Give Transaction access to modify history
    friend Account& operator+=(Account& acc, const Transaction& t);
};

// Implement operator+= here (friend of both classes)
Account& operator+=(Account& acc, const Transaction& t) {
    acc.history.push_back(t);
    return acc;
}

// ================= Savings Account =================
class SavingsAccount : public Account {
    double interestRate;

public:
    SavingsAccount(int accNo, string owner, double rate, double initialBalance = 0.0)
        : Account(accNo, owner, initialBalance), interestRate(rate) {}

    bool withdraw(double amount) override {
        double fee = amount * 0.02;
        double total = amount + fee;
        if (total > balance) {
            cout << "Insufficient funds (including fee).\n";
            return false;
        }
        balance -= total;
        *this += Transaction(amount, "Withdrawal (Savings + fee)");
        return true;
    }

    void applyInterest() {
        double interest = balance * (interestRate / 100.0);
        balance += interest;
        *this += Transaction(interest, "Interest Applied");
    }

    void display() const override {
        cout << "[Savings Account] ";
        Account::display();
        cout << "Interest Rate: " << interestRate << "%\n";
    }
};

// ================= Customer =================
class Customer {
    string name;
    int id;
    vector<shared_ptr<Account>> accounts;

public:
    Customer(string n, int i) : name(n), id(i) {}

    void openAccount(shared_ptr<Account> acc) {
        accounts.push_back(acc);
    }

    void showAccounts() const {
        cout << "Customer: " << name << " (ID: " << id << ")\n";
        for (auto& acc : accounts) {
            acc->display();
            cout << "-------------------------\n";
        }
    }

    double getTotalBalance() const {
        double total = 0;
        for (auto& acc : accounts)
            total += acc->getBalance();
        return total;
    }
};

// ================= Main =================
int main() {
    Customer c1("Alice", 101);

    auto acc1 = make_shared<Account>(1001, "Alice", 500);
    auto sav1 = make_shared<SavingsAccount>(2001, "Alice", 3.0, 1000);

    c1.openAccount(acc1);
    c1.openAccount(sav1);

    acc1->deposit(200);
    acc1->withdraw(100);

    sav1->deposit(500);
    sav1->withdraw(200);
    sav1->applyInterest();

    c1.showAccounts();

    return 0;
}
